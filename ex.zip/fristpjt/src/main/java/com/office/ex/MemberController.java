package com.office.ex;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("*.mem")

public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public MemberController() {
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
//		String requestURL = request.getRequestURI().toString();
		
		String RequestURI = request.getRequestURI();
//		
		String contextPath = request.getContextPath();
//		substring 스트링의 메서드, 문자열을 잘라서 출력
		String command = RequestURI.substring(contextPath.length());
		
		MemberService memberService = null;
		String nextPage = null;
		
		switch (command) {
		
		case "/signUp.mem": 
			
			nextPage = "view/member/signUp_form.jsp";

			break;
			
		case "/signUp_confirm.mem":
			
			memberService = new MemberService();
			
			int resultForSignUp = memberService.singUpConfirm(request, response);
			
			if (resultForSignUp == 1) {
				nextPage = "view/member/signUp_ok.jsp";
			} else {
				nextPage = "view/member/signUp_ng.jsp";
			}
			
			break;
		
		case "/signIn.mem": 
			
			break;
		
		}
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(nextPage);
		requestDispatcher.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)

			throws ServletException, IOException {
	
		request.setCharacterEncoding("UTF-8");
		
		doGet(request, response);
	}

}
