package com.office.ex;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MemberService {
	
	MemberDao memberDao = new MemberDao();

	public int singUpConfirm(HttpServletRequest request, HttpServletResponse response) {

		String memId = request.getParameter("memId");
		String memPw = request.getParameter("memPw");
		String memEmail = request.getParameter("memEmail");
		String memPhone = request.getParameter("memPhone");
		
		MemberDto memberDto = new MemberDto(memId, memPw, memEmail, memPhone);
		
		int result = memberDao.insertNewMember(memberDto);
		
		return 0;
	}



}
