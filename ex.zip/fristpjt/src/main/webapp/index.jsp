<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Insert title here</title>

</head>

<body>

	<div class="HOME">
		<h3>HOME</h3>
	</div>

	<div class="menu">
	
		<a href="/fristpjt/">HOME</a>
		&nbsp;&nbsp;|&nbsp; &nbsp;
	 
		<a href="/fristpjt/signUp.mem">회원 가입</a>
		&nbsp;&nbsp;|&nbsp; &nbsp; 
	
		<a href="/fristpjt/signIn.mem">로그인</a>
		&nbsp;&nbsp;|&nbsp; &nbsp; 
	

	
	</div>
	
	

</body>

</html>