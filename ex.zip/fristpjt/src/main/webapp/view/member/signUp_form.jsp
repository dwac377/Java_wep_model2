<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

		<a href="/fristpjt/">HOME</a>
		&nbsp;&nbsp;|&nbsp; &nbsp;
	 
		<a href="/fristpjt/signUp.mem">회원 가입</a>
		&nbsp;&nbsp;|&nbsp; &nbsp; 
	
		<a href="/fristpjt/signIn.mem">로그인</a>
		&nbsp;&nbsp;|&nbsp; &nbsp; 
		
		<form action="/frustpjt/signUp_confirm.mem" method="post">
		
			<input type="text" placeholder="새 아이디 입력">
			<br>
			<input type="password" placeholder="새 비밀번호 입력">
			<br>
			<input type="email" placeholder="이메일 입력">
			<br>
			<input type="text" placeholder="전화번호 입력">
			<br>
			<input type="submit" value="회원가입">
			<input type="reset" value="리셋">
		</form>

</body>
</html>